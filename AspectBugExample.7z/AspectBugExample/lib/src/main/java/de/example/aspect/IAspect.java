package de.example.aspect;

public interface IAspect
{
    String hello();
}
